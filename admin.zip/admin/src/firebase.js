// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
//   authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
//   projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
//   storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
//   messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
//   appId: process.env.REACT_APP_FIREBASE_APP_ID
// };
const firebaseConfig = {
  apiKey: "AIzaSyC79uPr3iRod26f9ja5Zmupni-rkLddi3I",
  authDomain: "back-d386a.firebaseapp.com",
  databaseURL: "https://back-d386a-default-rtdb.firebaseio.com",
  projectId: "back-d386a",
  storageBucket: "back-d386a.appspot.com",
  messagingSenderId: "227687255064",
  appId: "1:227687255064:web:07f66484768019e649876d",
  measurementId: "G-QR2HW14RKN"
};

// Initialize Firebase
export const firebaseApp = initializeApp(firebaseConfig);